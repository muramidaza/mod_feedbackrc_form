<div class="alert alert-danger" style="font-size: 1.5rem; height: 3rem">
	<?php echo $params['feedbackrc_error_message']?>
</div>